# ScreenResolution

This is a mod.

# EUPL
                      Copyright (c) 2025 SFGrenade
                      Licensed under the EUPL-1.2
https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
