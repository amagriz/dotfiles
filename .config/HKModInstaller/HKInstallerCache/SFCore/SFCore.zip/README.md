# SFCore

This is a library for mods aiming to add custom achievements, items and charms to the game.

# EUPL
                      Copyright (c) 2025 SFGrenade
                      Licensed under the EUPL-1.2
https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
